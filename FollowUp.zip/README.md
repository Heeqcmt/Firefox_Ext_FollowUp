# Firefox_Ext_FollowUp

Automatic update bookmark to better reflect where the user left off. 

If a page has been bookmarks, the extension will update the bookmark with the final url of the tab. 

Improvement

ask user to comfirm url change when user closes the tab.
